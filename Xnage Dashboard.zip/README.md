
  # Dashboard Wireframe for ManageX

  This is a code bundle for Dashboard Wireframe for ManageX. The original project is available at https://www.figma.com/design/pf9ci62FIddezkxuTSeyTU/Dashboard-Wireframe-for-ManageX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  