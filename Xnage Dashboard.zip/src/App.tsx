import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { ActivityPanel } from "./components/ActivityPanel";
import { Dashboard } from "./components/Dashboard";
import { LeadsPage } from "./components/LeadsPage";
import { ManageLeadsPage } from "./components/ManageLeadsPage";

export type UserRole = "manager" | "salesman";

export interface User {
  id: string;
  name: string;
  role: UserRole;
}

function App() {
  const [currentPage, setCurrentPage] = useState<
    "dashboard" | "leads" | "manage"
  >("dashboard");
  const [currentUser, setCurrentUser] = useState<User>({
    id: "1",
    name: "John Manager",
    role: "manager",
  });

  return (
    <div className="flex h-screen bg-[#1B2032]">
      {/* Left Sidebar Navigation */}
      <Sidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        currentUser={currentUser}
        onUserChange={setCurrentUser}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto">
        {currentPage === "dashboard" ? (
          <Dashboard currentUser={currentUser} />
        ) : currentPage === "leads" ? (
          <LeadsPage currentUser={currentUser} />
        ) : (
          <ManageLeadsPage currentUser={currentUser} />
        )}
      </main>

      {/* Right Activity Panel */}
      <ActivityPanel />
    </div>
  );
}

export default App;