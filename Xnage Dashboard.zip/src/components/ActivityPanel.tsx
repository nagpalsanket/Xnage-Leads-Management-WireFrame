import { Circle, CheckCircle, Mail, Phone, Edit } from 'lucide-react';

interface Activity {
  id: string;
  salesman: string;
  action: string;
  leadName: string;
  timestamp: string;
  type: 'approved' | 'contacted_email' | 'contacted_phone' | 'marked' | 'edited';
  isOnline: boolean;
}

const mockActivities: Activity[] = [
  { id: '1', salesman: 'Sarah Sales', action: 'Approved lead', leadName: 'Acme Corp', timestamp: '2 min ago', type: 'approved', isOnline: true },
  { id: '2', salesman: 'Mike Sales', action: 'Contacted via email', leadName: 'TechStart Inc', timestamp: '5 min ago', type: 'contacted_email', isOnline: true },
  { id: '3', salesman: 'Emma Sales', action: 'Marked as qualified', leadName: 'Global Systems', timestamp: '12 min ago', type: 'marked', isOnline: true },
  { id: '4', salesman: 'Sarah Sales', action: 'Contacted via phone', leadName: 'Digital Wave', timestamp: '18 min ago', type: 'contacted_phone', isOnline: true },
  { id: '5', salesman: 'Mike Sales', action: 'Updated lead info', leadName: 'CloudBase Ltd', timestamp: '25 min ago', type: 'edited', isOnline: true },
  { id: '6', salesman: 'Emma Sales', action: 'Approved lead', leadName: 'DataFlow Co', timestamp: '32 min ago', type: 'approved', isOnline: true },
  { id: '7', salesman: 'Sarah Sales', action: 'Contacted via email', leadName: 'NextGen Solutions', timestamp: '1 hr ago', type: 'contacted_email', isOnline: true },
];

const salesmen = [
  { name: 'Sarah Sales', status: 'online', activeLeads: 12 },
  { name: 'Mike Sales', status: 'online', activeLeads: 8 },
  { name: 'Emma Sales', status: 'online', activeLeads: 15 },
  { name: 'Tom Sales', status: 'offline', activeLeads: 5 },
];

export function ActivityPanel() {
  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'contacted_email':
        return <Mail className="w-4 h-4 text-blue-400" />;
      case 'contacted_phone':
        return <Phone className="w-4 h-4 text-purple-400" />;
      case 'edited':
        return <Edit className="w-4 h-4 text-orange-400" />;
      default:
        return <Circle className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="w-80 bg-[#1B2032] border-l border-gray-700 overflow-auto">
      {/* Active Salesmen */}
      <div className="p-6 border-b border-gray-700">
        <h2 className="mb-4 text-white">Active Salesmen</h2>
        <div className="space-y-3">
          {salesmen.map((salesman) => (
            <div key={salesman.name} className="flex items-center gap-3">
              <div className="relative">
                <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                  <span className="text-xs text-gray-300">{salesman.name.split(' ').map(n => n[0]).join('')}</span>
                </div>
                <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#1B2032] ${
                  salesman.status === 'online' ? 'bg-green-500' : 'bg-gray-400'
                }`} />
              </div>
              <div className="flex-1">
                <div className="text-sm text-white">{salesman.name}</div>
                <div className="text-xs text-gray-400">{salesman.activeLeads} active leads</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="p-6">
        <h2 className="mb-4 text-white">Recent Activity</h2>
        <div className="space-y-4">
          {mockActivities.map((activity) => (
            <div key={activity.id} className="flex gap-3">
              <div className="mt-1">
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1">
                <div className="text-sm text-white">
                  <span>{activity.salesman}</span>
                </div>
                <div className="text-xs text-gray-400">
                  {activity.action}
                </div>
                <div className="text-xs text-[#4EBA48] mt-1 font-medium">
                  {activity.leadName}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {activity.timestamp}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}