import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { User } from '../App';

interface DashboardProps {
  currentUser: User;
}

const leadsPerTimeData = [
  { date: 'Mon', leads: 45 },
  { date: 'Tue', leads: 52 },
  { date: 'Wed', leads: 48 },
  { date: 'Thu', leads: 61 },
  { date: 'Fri', leads: 55 },
  { date: 'Sat', leads: 38 },
  { date: 'Sun', leads: 42 },
];

const resolvedPerTimeData = [
  { date: 'Mon', resolved: 28 },
  { date: 'Tue', resolved: 35 },
  { date: 'Wed', resolved: 31 },
  { date: 'Thu', resolved: 42 },
  { date: 'Fri', resolved: 38 },
  { date: 'Sat', resolved: 25 },
  { date: 'Sun', resolved: 29 },
];

const salesmanPerformance = [
  { name: 'Sarah Sales', contacted: 45, qualified: 32, converted: 18 },
  { name: 'Mike Sales', contacted: 38, qualified: 28, converted: 15 },
  { name: 'Emma Sales', contacted: 52, qualified: 41, converted: 24 },
  { name: 'Tom Sales', contacted: 29, qualified: 19, converted: 10 },
];

export function Dashboard({ currentUser }: DashboardProps) {
  const [chartView, setChartView] = useState<'leads' | 'resolved'>('leads');

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="mb-2 text-white">Dashboard</h1>
        <p className="text-gray-300">
          Welcome back, {currentUser.name}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700">
          <div className="text-gray-400 text-sm mb-2">Total Leads</div>
          <div className="text-[#4EBA48] border-b-2 border-[#4EBA48] inline-block pb-1">341</div>
          <div className="text-xs text-green-400 mt-2">+12% from last week</div>
        </div>
        <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700">
          <div className="text-gray-400 text-sm mb-2">Qualified Leads</div>
          <div className="text-[#4EBA48] border-b-2 border-[#4EBA48] inline-block pb-1">228</div>
          <div className="text-xs text-green-400 mt-2">+8% from last week</div>
        </div>
        <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700">
          <div className="text-gray-400 text-sm mb-2">Converted</div>
          <div className="text-purple-400 border-b-2 border-[#4EBA48] inline-block pb-1">67</div>
          <div className="text-xs text-green-400 mt-2">+15% from last week</div>
        </div>
        <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700">
          <div className="text-gray-400 text-sm mb-2">Conversion Rate</div>
          <div className="text-orange-400 border-b-2 border-[#4EBA48] inline-block pb-1">19.6%</div>
          <div className="text-xs text-green-400 mt-2">+2.3% from last week</div>
        </div>
      </div>

      {/* Main Chart */}
      <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-white">Performance Overview</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setChartView('leads')}
              className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                chartView === 'leads'
                  ? 'bg-[#4EBA48] text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              Leads Per Time
            </button>
            <button
              onClick={() => setChartView('resolved')}
              className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                chartView === 'resolved'
                  ? 'bg-[#4EBA48] text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              Resolved Per Time
            </button>
          </div>
        </div>
        
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartView === 'leads' ? leadsPerTimeData : resolvedPerTimeData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1B2032', border: '1px solid #374151', color: '#fff' }}
              labelStyle={{ color: '#9CA3AF' }}
            />
            <Legend wrapperStyle={{ color: '#9CA3AF' }} />
            <Line 
              type="monotone" 
              dataKey={chartView === 'leads' ? 'leads' : 'resolved'} 
              stroke="#4EBA48" 
              strokeWidth={3}
              name={chartView === 'leads' ? 'New Leads' : 'Resolved Leads'}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Individual Salesman Performance */}
      {currentUser.role === 'manager' && (
        <div className="bg-[#252b3f] p-6 rounded-lg border border-gray-700">
          <h2 className="mb-6 text-white">Top Salesmen Performance</h2>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={salesmanPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1B2032', border: '1px solid #374151', color: '#fff' }}
                labelStyle={{ color: '#9CA3AF' }}
              />
              <Legend wrapperStyle={{ color: '#9CA3AF' }} />
              <Bar dataKey="contacted" fill="#3b82f6" name="Contacted" />
              <Bar dataKey="qualified" fill="#4EBA48" name="Qualified" />
              <Bar dataKey="converted" fill="#8b5cf6" name="Converted" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}