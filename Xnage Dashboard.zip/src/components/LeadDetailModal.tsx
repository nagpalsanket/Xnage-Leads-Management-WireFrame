import { X, Mail, Phone, DollarSign, User, Calendar, FileText } from 'lucide-react';
import type { User } from '../App';
import { useState } from 'react';

interface Lead {
  id: string;
  company: string;
  contact: string;
  email: string;
  phone: string;
  status: 'new' | 'contacted' | 'qualified' | 'converted' | 'lost';
  assignedTo: string;
  lastContacted: string;
  lastReviewedBy: string;
  source: string;
  value: string;
  notes: string;
  history: Array<{
    action: string;
    by: string;
    timestamp: string;
  }>;
}

interface LeadDetailModalProps {
  lead: Lead;
  onClose: () => void;
  onUpdate: (lead: Lead) => void;
  currentUser: User;
}

export function LeadDetailModal({ lead, onClose, onUpdate, currentUser }: LeadDetailModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedNotes, setEditedNotes] = useState(lead.notes);
  const [editedValue, setEditedValue] = useState(lead.value);

  const handleSave = () => {
    const updatedLead = {
      ...lead,
      notes: editedNotes,
      value: editedValue,
      history: [
        { action: 'Lead information updated', by: currentUser.name, timestamp: 'Just now' },
        ...lead.history
      ]
    };
    onUpdate(updatedLead);
    setIsEditing(false);
  };

  const getStatusColor = (status: Lead['status']) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-700';
      case 'contacted': return 'bg-yellow-100 text-yellow-700';
      case 'qualified': return 'bg-purple-100 text-purple-700';
      case 'converted': return 'bg-green-100 text-green-700';
      case 'lost': return 'bg-red-100 text-red-700';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-[#252b3f] rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-gray-700">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div>
            <h2 className="mb-1 text-white">{lead.company}</h2>
            <div className="flex items-center gap-3">
              <span className={`px-3 py-1 rounded-full text-xs capitalize ${getStatusColor(lead.status)}`}>
                {lead.status}
              </span>
              <span className="text-sm text-gray-400">ID: {lead.id}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-300" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          <div className="grid grid-cols-2 gap-8">
            {/* Left Column - Contact Info */}
            <div>
              <h3 className="mb-4 pb-2 border-b border-gray-700 text-white">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Contact Person</div>
                    <div className="text-white">{lead.contact}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Email</div>
                    <a href={`mailto:${lead.email}`} className="text-[#4EBA48] hover:underline">
                      {lead.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Phone</div>
                    <a href={`tel:${lead.phone}`} className="text-[#4EBA48] hover:underline">
                      {lead.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <DollarSign className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Estimated Value</div>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedValue}
                        onChange={(e) => setEditedValue(e.target.value)}
                        className="border border-gray-600 bg-[#1B2032] text-white rounded px-2 py-1 text-sm"
                      />
                    ) : (
                      <div className="text-white border-b-2 border-[#4EBA48] inline-block">{lead.value}</div>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Assigned To</div>
                    <div className="text-white">{lead.assignedTo}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Last Contacted</div>
                    <div className="text-white">{lead.lastContacted}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <FileText className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <div className="text-sm text-gray-400">Source</div>
                    <div className="text-white">{lead.source}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Notes & History */}
            <div>
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-700">
                  <h3 className="text-white">Notes</h3>
                  {!isEditing && (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-sm text-[#4EBA48] hover:text-green-400"
                    >
                      Edit
                    </button>
                  )}
                </div>
                {isEditing ? (
                  <textarea
                    value={editedNotes}
                    onChange={(e) => setEditedNotes(e.target.value)}
                    className="w-full h-32 p-3 border border-gray-600 bg-[#1B2032] text-white rounded-lg text-sm"
                    placeholder="Add notes about this lead..."
                  />
                ) : (
                  <p className="text-sm text-gray-300">{lead.notes}</p>
                )}
              </div>

              <div>
                <h3 className="mb-4 pb-2 border-b border-gray-700 text-white">Activity History</h3>
                <div className="space-y-4">
                  {lead.history.map((item, index) => (
                    <div key={index} className="flex gap-3">
                      <div className="w-2 h-2 bg-[#4EBA48] rounded-full mt-2" />
                      <div className="flex-1">
                        <div className="text-sm text-white">{item.action}</div>
                        <div className="text-xs text-gray-400 mt-1">
                          {item.by} • {item.timestamp}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-700">
          {isEditing ? (
            <>
              <button
                onClick={() => {
                  setIsEditing(false);
                  setEditedNotes(lead.notes);
                  setEditedValue(lead.value);
                }}
                className="px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#4EBA48] text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                Save Changes
              </button>
            </>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors"
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
}