import { useState } from 'react';
import { Search, Filter, ChevronDown, Mail, Phone, Calendar, User } from 'lucide-react';
import type { User } from '../App';
import { LeadDetailModal } from './LeadDetailModal';

interface Lead {
  id: string;
  company: string;
  contact: string;
  email: string;
  phone: string;
  status: 'new' | 'contacted' | 'qualified' | 'converted' | 'lost';
  assignedTo: string;
  lastContacted: string;
  lastReviewedBy: string;
  source: string;
  value: string;
  notes: string;
  history: Array<{
    action: string;
    by: string;
    timestamp: string;
  }>;
}

const mockLeads: Lead[] = [
  {
    id: '1',
    company: 'Acme Corp',
    contact: 'Jane Smith',
    email: 'jane@acmecorp.com',
    phone: '+1 234-567-8901',
    status: 'qualified',
    assignedTo: 'Sarah Sales',
    lastContacted: '2 hours ago',
    lastReviewedBy: 'Sarah Sales',
    source: 'Website',
    value: '$25,000',
    notes: 'Interested in enterprise package. Follow up next week.',
    history: [
      { action: 'Marked as qualified', by: 'Sarah Sales', timestamp: '2 hours ago' },
      { action: 'Contacted via email', by: 'Sarah Sales', timestamp: '1 day ago' },
      { action: 'Lead created', by: 'System', timestamp: '3 days ago' },
    ]
  },
  {
    id: '2',
    company: 'TechStart Inc',
    contact: 'Bob Johnson',
    email: 'bob@techstart.io',
    phone: '+1 234-567-8902',
    status: 'contacted',
    assignedTo: 'Mike Sales',
    lastContacted: '1 day ago',
    lastReviewedBy: 'Mike Sales',
    source: 'Referral',
    value: '$15,000',
    notes: 'Waiting for budget approval from CFO.',
    history: [
      { action: 'Contacted via email', by: 'Mike Sales', timestamp: '1 day ago' },
      { action: 'Lead assigned', by: 'John Manager', timestamp: '2 days ago' },
      { action: 'Lead created', by: 'System', timestamp: '2 days ago' },
    ]
  },
  {
    id: '3',
    company: 'Global Systems',
    contact: 'Alice Williams',
    email: 'alice@globalsys.com',
    phone: '+1 234-567-8903',
    status: 'new',
    assignedTo: 'Emma Sales',
    lastContacted: 'Never',
    lastReviewedBy: 'Emma Sales',
    source: 'Cold Call',
    value: '$40,000',
    notes: 'Large potential client. High priority.',
    history: [
      { action: 'Lead assigned', by: 'John Manager', timestamp: '3 hours ago' },
      { action: 'Lead created', by: 'Emma Sales', timestamp: '4 hours ago' },
    ]
  },
  {
    id: '4',
    company: 'Digital Wave',
    contact: 'Charlie Brown',
    email: 'charlie@digitalwave.co',
    phone: '+1 234-567-8904',
    status: 'converted',
    assignedTo: 'Sarah Sales',
    lastContacted: '3 days ago',
    lastReviewedBy: 'John Manager',
    source: 'LinkedIn',
    value: '$32,000',
    notes: 'Deal closed! Contract signed.',
    history: [
      { action: 'Marked as converted', by: 'Sarah Sales', timestamp: '3 days ago' },
      { action: 'Proposal sent', by: 'Sarah Sales', timestamp: '1 week ago' },
      { action: 'Demo scheduled', by: 'Sarah Sales', timestamp: '2 weeks ago' },
    ]
  },
  {
    id: '5',
    company: 'CloudBase Ltd',
    contact: 'Diana Ross',
    email: 'diana@cloudbase.com',
    phone: '+1 234-567-8905',
    status: 'qualified',
    assignedTo: 'Mike Sales',
    lastContacted: '5 hours ago',
    lastReviewedBy: 'Mike Sales',
    source: 'Website',
    value: '$18,500',
    notes: 'Needs custom integration. Technical call scheduled.',
    history: [
      { action: 'Contacted via phone', by: 'Mike Sales', timestamp: '5 hours ago' },
      { action: 'Marked as qualified', by: 'Mike Sales', timestamp: '1 day ago' },
    ]
  },
];

interface LeadsPageProps {
  currentUser: User;
}

export function LeadsPage({ currentUser }: LeadsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [hoveredLead, setHoveredLead] = useState<string | null>(null);
  const [leads, setLeads] = useState(mockLeads);

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = lead.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lead.contact.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: Lead['status']) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-700';
      case 'contacted': return 'bg-yellow-100 text-yellow-700';
      case 'qualified': return 'bg-purple-100 text-purple-700';
      case 'converted': return 'bg-green-100 text-green-700';
      case 'lost': return 'bg-red-100 text-red-700';
    }
  };

  const handleStatusChange = (leadId: string, newStatus: Lead['status']) => {
    setLeads(prevLeads => 
      prevLeads.map(lead => 
        lead.id === leadId 
          ? { 
              ...lead, 
              status: newStatus,
              history: [
                { action: `Status changed to ${newStatus}`, by: currentUser.name, timestamp: 'Just now' },
                ...lead.history
              ]
            }
          : lead
      )
    );
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="mb-2 text-white">Leads Management</h1>
        <p className="text-gray-300">
          Manage and track all sales leads
        </p>
      </div>

      {/* Filters */}
      <div className="bg-[#252b3f] p-4 rounded-lg border border-gray-700 mb-6">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search leads by company or contact..."
              className="w-full pl-10 pr-4 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg placeholder-gray-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <select
              className="pl-10 pr-8 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg appearance-none"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="qualified">Qualified</option>
              <option value="converted">Converted</option>
              <option value="lost">Lost</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-[#252b3f] rounded-lg border border-gray-700 overflow-hidden">
        <table className="w-full">
          <thead className="bg-[#1B2032] border-b border-gray-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Company</th>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Contact</th>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Assigned To</th>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Value</th>
              <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {filteredLeads.map((lead) => (
              <tr 
                key={lead.id}
                className="hover:bg-[#2a3142] transition-colors relative"
                onMouseEnter={() => setHoveredLead(lead.id)}
                onMouseLeave={() => setHoveredLead(null)}
              >
                <td className="px-6 py-4">
                  <div>
                    <div className="text-white">{lead.company}</div>
                    <div className="text-sm text-gray-400">{lead.source}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div>
                    <div className="text-sm text-white">{lead.contact}</div>
                    <div className="text-xs text-gray-400">{lead.email}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <select
                    value={lead.status}
                    onChange={(e) => handleStatusChange(lead.id, e.target.value as Lead['status'])}
                    className={`px-3 py-1 rounded-full text-xs capitalize ${getStatusColor(lead.status)}`}
                  >
                    <option value="new">New</option>
                    <option value="contacted">Contacted</option>
                    <option value="qualified">Qualified</option>
                    <option value="converted">Converted</option>
                    <option value="lost">Lost</option>
                  </select>
                </td>
                <td className="px-6 py-4 text-sm text-white">{lead.assignedTo}</td>
                <td className="px-6 py-4 text-white">{lead.value}</td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => setSelectedLead(lead)}
                    className="text-[#4EBA48] hover:text-green-400 text-sm font-medium"
                  >
                    View Details
                  </button>
                </td>

                {/* Hover Tooltip */}
                {hoveredLead === lead.id && (
                  <div className="absolute left-0 right-0 top-full mt-2 mx-6 bg-[#252b3f] border border-gray-600 rounded-lg shadow-lg p-4 z-10">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-start gap-2">
                        <Calendar className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <div className="text-xs text-gray-400">Last Contacted</div>
                          <div className="text-white">{lead.lastContacted}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <User className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <div className="text-xs text-gray-400">Last Reviewed By</div>
                          <div className="text-white">{lead.lastReviewedBy}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Mail className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <div className="text-xs text-gray-400">Email</div>
                          <div className="text-white">{lead.email}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <Phone className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <div className="text-xs text-gray-400">Phone</div>
                          <div className="text-white">{lead.phone}</div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-700">
                      <div className="text-xs text-gray-400 mb-1">Recent Changes</div>
                      <div className="text-xs text-white">
                        {lead.history[0]?.action} • {lead.history[0]?.by}
                      </div>
                    </div>
                  </div>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Lead Detail Modal */}
      {selectedLead && (
        <LeadDetailModal
          lead={selectedLead}
          onClose={() => setSelectedLead(null)}
          onUpdate={(updatedLead) => {
            setLeads(prevLeads =>
              prevLeads.map(l => l.id === updatedLead.id ? updatedLead : l)
            );
            setSelectedLead(updatedLead);
          }}
          currentUser={currentUser}
        />
      )}
    </div>
  );
}