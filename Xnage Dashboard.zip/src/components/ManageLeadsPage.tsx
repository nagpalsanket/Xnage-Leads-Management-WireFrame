import { useState } from 'react';
import { Search, Filter, ChevronDown, Save, X, Check, Plus } from 'lucide-react';
import type { User } from '../App';

interface Lead {
  id: string;
  company: string;
  contact: string;
  email: string;
  phone: string;
  status: 'new' | 'contacted' | 'qualified' | 'converted' | 'lost';
  assignedTo: string;
  source: string;
  value: string;
  notes: string;
}

const mockLeads: Lead[] = [
  {
    id: '1',
    company: 'Acme Corp',
    contact: 'Jane Smith',
    email: 'jane@acmecorp.com',
    phone: '+1 234-567-8901',
    status: 'qualified',
    assignedTo: 'Sarah Sales',
    source: 'Website',
    value: '$25,000',
    notes: 'Interested in enterprise package. Follow up next week.',
  },
  {
    id: '2',
    company: 'TechStart Inc',
    contact: 'Bob Johnson',
    email: 'bob@techstart.io',
    phone: '+1 234-567-8902',
    status: 'contacted',
    assignedTo: 'Mike Sales',
    source: 'Referral',
    value: '$15,000',
    notes: 'Waiting for budget approval from CFO.',
  },
  {
    id: '3',
    company: 'Global Systems',
    contact: 'Alice Williams',
    email: 'alice@globalsys.com',
    phone: '+1 234-567-8903',
    status: 'new',
    assignedTo: 'Emma Sales',
    source: 'Cold Call',
    value: '$40,000',
    notes: 'Large potential client. High priority.',
  },
  {
    id: '4',
    company: 'Digital Wave',
    contact: 'Charlie Brown',
    email: 'charlie@digitalwave.co',
    phone: '+1 234-567-8904',
    status: 'converted',
    assignedTo: 'Sarah Sales',
    source: 'LinkedIn',
    value: '$32,000',
    notes: 'Deal closed! Contract signed.',
  },
  {
    id: '5',
    company: 'CloudBase Ltd',
    contact: 'Diana Ross',
    email: 'diana@cloudbase.com',
    phone: '+1 234-567-8905',
    status: 'qualified',
    assignedTo: 'Mike Sales',
    source: 'Website',
    value: '$18,500',
    notes: 'Needs custom integration. Technical call scheduled.',
  },
];

const salespeople = ['Sarah Sales', 'Mike Sales', 'Emma Sales', 'Tom Sales'];

interface ManageLeadsPageProps {
  currentUser: User;
}

export function ManageLeadsPage({ currentUser }: ManageLeadsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [leads, setLeads] = useState(mockLeads);
  const [editingCell, setEditingCell] = useState<{ leadId: string; field: string } | null>(null);
  const [editValue, setEditValue] = useState('');
  const [savedCells, setSavedCells] = useState<Set<string>>(new Set());
  const [showAddForm, setShowAddForm] = useState(false);
  const [newLead, setNewLead] = useState<Lead>({
    id: '',
    company: '',
    contact: '',
    email: '',
    phone: '',
    status: 'new',
    assignedTo: currentUser.name,
    source: 'Manual Entry',
    value: '$0',
    notes: '',
  });

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = lead.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lead.contact.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: Lead['status']) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-700';
      case 'contacted': return 'bg-yellow-100 text-yellow-700';
      case 'qualified': return 'bg-purple-100 text-purple-700';
      case 'converted': return 'bg-green-100 text-green-700';
      case 'lost': return 'bg-red-100 text-red-700';
    }
  };

  const startEdit = (leadId: string, field: string, currentValue: string) => {
    setEditingCell({ leadId, field });
    setEditValue(currentValue);
  };

  const cancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  const saveEdit = (leadId: string, field: keyof Lead) => {
    setLeads(prevLeads =>
      prevLeads.map(lead =>
        lead.id === leadId ? { ...lead, [field]: editValue } : lead
      )
    );
    
    // Mark cell as saved with animation
    const cellKey = `${leadId}-${field}`;
    setSavedCells(prev => new Set(prev).add(cellKey));
    setTimeout(() => {
      setSavedCells(prev => {
        const newSet = new Set(prev);
        newSet.delete(cellKey);
        return newSet;
      });
    }, 2000);
    
    setEditingCell(null);
    setEditValue('');
  };

  const handleAddLead = () => {
    if (!newLead.company || !newLead.contact) {
      alert('Please fill in at least Company and Contact fields');
      return;
    }

    const leadToAdd = {
      ...newLead,
      id: String(Date.now()),
    };

    setLeads(prevLeads => [leadToAdd, ...prevLeads]);
    setShowAddForm(false);
    setNewLead({
      id: '',
      company: '',
      contact: '',
      email: '',
      phone: '',
      status: 'new',
      assignedTo: currentUser.name,
      source: 'Manual Entry',
      value: '$0',
      notes: '',
    });
  };

  const cancelAddLead = () => {
    setShowAddForm(false);
    setNewLead({
      id: '',
      company: '',
      contact: '',
      email: '',
      phone: '',
      status: 'new',
      assignedTo: currentUser.name,
      source: 'Manual Entry',
      value: '$0',
      notes: '',
    });
  };

  const renderEditableCell = (lead: Lead, field: keyof Lead, value: string) => {
    const isEditing = editingCell?.leadId === lead.id && editingCell?.field === field;
    const cellKey = `${lead.id}-${field}`;
    const isSaved = savedCells.has(cellKey);

    if (isEditing) {
      return (
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            className="flex-1 px-2 py-1 border border-[#4EBA48] bg-[#1B2032] text-white rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#4EBA48]"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === 'Enter') saveEdit(lead.id, field);
              if (e.key === 'Escape') cancelEdit();
            }}
          />
          <button
            onClick={() => saveEdit(lead.id, field)}
            className="p-1 text-green-400 hover:bg-green-900 hover:bg-opacity-30 rounded"
          >
            <Check className="w-4 h-4" />
          </button>
          <button
            onClick={cancelEdit}
            className="p-1 text-red-400 hover:bg-red-900 hover:bg-opacity-30 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      );
    }

    return (
      <div
        onClick={() => startEdit(lead.id, field as string, value)}
        className={`cursor-pointer px-2 py-1 rounded hover:bg-[#2a3142] transition-colors ${
          isSaved ? 'bg-green-900 bg-opacity-30 animate-pulse' : ''
        }`}
      >
        {value}
        {isSaved && (
          <span className="ml-2 text-[#4EBA48] text-xs font-medium">Saved!</span>
        )}
      </div>
    );
  };

  const renderEditableSelect = (lead: Lead, field: 'status' | 'assignedTo') => {
    const isEditing = editingCell?.leadId === lead.id && editingCell?.field === field;
    const cellKey = `${lead.id}-${field}`;
    const isSaved = savedCells.has(cellKey);

    if (isEditing) {
      return (
        <div className="flex items-center gap-2">
          <select
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            className="flex-1 px-2 py-1 border border-[#4EBA48] bg-[#1B2032] text-white rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#4EBA48]"
            autoFocus
          >
            {field === 'status' ? (
              <>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="converted">Converted</option>
                <option value="lost">Lost</option>
              </>
            ) : (
              salespeople.map(person => (
                <option key={person} value={person}>{person}</option>
              ))
            )}
          </select>
          <button
            onClick={() => saveEdit(lead.id, field)}
            className="p-1 text-green-400 hover:bg-green-900 hover:bg-opacity-30 rounded"
          >
            <Check className="w-4 h-4" />
          </button>
          <button
            onClick={cancelEdit}
            className="p-1 text-red-400 hover:bg-red-900 hover:bg-opacity-30 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      );
    }

    const displayValue = field === 'status' ? (
      <span className={`px-3 py-1 rounded-full text-xs capitalize ${getStatusColor(lead[field])}`}>
        {lead[field]}
      </span>
    ) : (
      lead[field]
    );

    return (
      <div
        onClick={() => startEdit(lead.id, field, lead[field])}
        className={`cursor-pointer px-2 py-1 rounded hover:bg-[#2a3142] transition-colors ${
          isSaved ? 'bg-green-900 bg-opacity-30' : ''
        }`}
      >
        {displayValue}
        {isSaved && (
          <span className="ml-2 text-[#4EBA48] text-xs font-medium">Saved!</span>
        )}
      </div>
    );
  };

  const renderEditableTextarea = (lead: Lead) => {
    const isEditing = editingCell?.leadId === lead.id && editingCell?.field === 'notes';
    const cellKey = `${lead.id}-notes`;
    const isSaved = savedCells.has(cellKey);

    if (isEditing) {
      return (
        <div className="flex flex-col gap-2">
          <textarea
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            className="w-full px-2 py-1 border border-[#4EBA48] bg-[#1B2032] text-white rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#4EBA48]"
            rows={3}
            autoFocus
          />
          <div className="flex gap-2">
            <button
              onClick={() => saveEdit(lead.id, 'notes')}
              className="px-3 py-1 bg-[#4EBA48] text-white rounded text-sm hover:bg-green-600 flex items-center gap-1"
            >
              <Check className="w-3 h-3" />
              Save
            </button>
            <button
              onClick={cancelEdit}
              className="px-3 py-1 bg-gray-700 text-gray-300 rounded text-sm hover:bg-gray-600 flex items-center gap-1"
            >
              <X className="w-3 h-3" />
              Cancel
            </button>
          </div>
        </div>
      );
    }

    return (
      <div
        onClick={() => startEdit(lead.id, 'notes', lead.notes)}
        className={`cursor-pointer px-2 py-1 rounded hover:bg-[#2a3142] transition-colors text-sm ${
          isSaved ? 'bg-green-900 bg-opacity-30' : ''
        }`}
      >
        <div className="line-clamp-2">{lead.notes}</div>
        {isSaved && (
          <span className="text-[#4EBA48] text-xs font-medium">Saved!</span>
        )}
      </div>
    );
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="mb-2 text-white">Manage Leads</h1>
          <p className="text-gray-300">
            Click on any cell to edit. All changes are saved automatically.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-[#4EBA48] text-white rounded-lg hover:bg-green-600 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add New Lead
        </button>
      </div>

      {/* Add New Lead Form */}
      {showAddForm && (
        <div className="bg-[#252b3f] p-6 rounded-lg border-2 border-[#4EBA48] mb-6 shadow-lg">
          <h2 className="mb-4 text-white">Add New Lead</h2>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1">Company *</label>
              <input
                type="text"
                value={newLead.company}
                onChange={(e) => setNewLead({ ...newLead, company: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="Company name"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Contact Person *</label>
              <input
                type="text"
                value={newLead.contact}
                onChange={(e) => setNewLead({ ...newLead, contact: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="Contact name"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Email</label>
              <input
                type="email"
                value={newLead.email}
                onChange={(e) => setNewLead({ ...newLead, email: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="email@example.com"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Phone</label>
              <input
                type="tel"
                value={newLead.phone}
                onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="+1 234-567-8900"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Status</label>
              <select
                value={newLead.status}
                onChange={(e) => setNewLead({ ...newLead, status: e.target.value as Lead['status'] })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48]"
              >
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="converted">Converted</option>
                <option value="lost">Lost</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Assigned To</label>
              <select
                value={newLead.assignedTo}
                onChange={(e) => setNewLead({ ...newLead, assignedTo: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48]"
              >
                {salespeople.map(person => (
                  <option key={person} value={person}>{person}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Estimated Value</label>
              <input
                type="text"
                value={newLead.value}
                onChange={(e) => setNewLead({ ...newLead, value: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="$0"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Source</label>
              <input
                type="text"
                value={newLead.source}
                onChange={(e) => setNewLead({ ...newLead, source: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                placeholder="e.g., Website, Referral"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm text-gray-400 mb-1">Notes</label>
              <textarea
                value={newLead.notes}
                onChange={(e) => setNewLead({ ...newLead, notes: e.target.value })}
                className="w-full px-3 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-[#4EBA48] placeholder-gray-500"
                rows={3}
                placeholder="Add any additional notes..."
              />
            </div>
          </div>
          <div className="flex gap-3 justify-end">
            <button
              onClick={cancelAddLead}
              className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleAddLead}
              className="px-4 py-2 bg-[#4EBA48] text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              Add Lead
            </button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-[#252b3f] p-4 rounded-lg border border-gray-700 mb-6">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search leads by company or contact..."
              className="w-full pl-10 pr-4 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg placeholder-gray-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <select
              className="pl-10 pr-8 py-2 border border-gray-600 bg-[#1B2032] text-white rounded-lg appearance-none"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="qualified">Qualified</option>
              <option value="converted">Converted</option>
              <option value="lost">Lost</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Editable Leads Table */}
      <div className="bg-[#252b3f] rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#1B2032] border-b border-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Company</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Contact</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Phone</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Assigned To</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Value</th>
                <th className="px-6 py-3 text-left text-xs text-gray-400 uppercase tracking-wider">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {filteredLeads.map((lead) => (
                <tr key={lead.id} className="hover:bg-[#2a3142] transition-colors">
                  <td className="px-6 py-4 text-white">
                    {renderEditableCell(lead, 'company', lead.company)}
                  </td>
                  <td className="px-6 py-4 text-white">
                    {renderEditableCell(lead, 'contact', lead.contact)}
                  </td>
                  <td className="px-6 py-4 text-white">
                    {renderEditableCell(lead, 'email', lead.email)}
                  </td>
                  <td className="px-6 py-4 text-white">
                    {renderEditableCell(lead, 'phone', lead.phone)}
                  </td>
                  <td className="px-6 py-4">
                    {renderEditableSelect(lead, 'status')}
                  </td>
                  <td className="px-6 py-4 text-white">
                    {renderEditableSelect(lead, 'assignedTo')}
                  </td>
                  <td className="px-6 py-4 text-white">
                    {renderEditableCell(lead, 'value', lead.value)}
                  </td>
                  <td className="px-6 py-4 max-w-xs text-white">
                    {renderEditableTextarea(lead)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Helper Text */}
      <div className="mt-4 p-4 bg-[#4EBA48] bg-opacity-10 border border-[#4EBA48] rounded-lg">
        <p className="text-sm text-gray-200">
          <strong className="text-[#4EBA48]">Tip:</strong> Click any cell to edit inline. Press Enter to save or Escape to cancel. Changes are saved automatically with visual confirmation.
        </p>
      </div>
    </div>
  );
}